import graphviz as gv



##
dom_tree = []
with open('domtree.txt') as fe:
    for line in fe:
        e = line.split()
        dom_tree.append((e[0],e[1]))


f = open('dfnum.txt', 'w')
print dom_tree[0][0]
f.write('(' + str(1) + ', '+ str(dom_tree[0][0])+ ')' + '\n')
n = 1
for i in dom_tree:
    n+=1
    f.write('('+str(n)+', '+ str(i[1])+ ')' + '\n')
    print i[1]

f.close()
t = {}
for i in dom_tree:
    for j in i:
        if j not in t:
            t[j] = 0

nodes = [x for x in t]
dfsgraph= gv.Graph(format='jpg')
for i in nodes:
    dfsgraph.node(str(i))
for i in dom_tree:
    dfsgraph.edge(str(i[0]),str(i[1]))

dfsgraph.render(filename='img/dfsgraph')
