gcc -ftree-vectorize -ftree-vectorizer-verbose=1 -O2 ./main/vec.c  -o vec.o
