#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int test_fun(int a){
    int b=a;
    return b;
}

int main(){
    float i=10.23;
    return 0;
}

