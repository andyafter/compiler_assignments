gcc -c ./tests/basic.s -o output/basic_test.o
gcc ./output/basic_test.o -o basic_test
