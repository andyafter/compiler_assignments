#include<stdio.h>
#include<time.h>
#include<stdlib.h>


int basic_matrix_multiplication(){
    return 0;
}
