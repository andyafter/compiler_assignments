cd output/
rm *
cd ../
rm scratch
rm ./tests/scratch.s 
make
